
import React, { useState } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";

const breeds = [
  {
    name: "Golden Retriever",
    size: "Large",
    temperament: "Friendly, Intelligent, Devoted",
    living: "Best in homes with yards, active families",
    image: "https://images.unsplash.com/photo-1558788353-f76d92427f16",
    slug: "golden-retriever",
    affiliate: "https://www.amazon.com/s?k=golden+retriever+dog+toys",
    details: "Golden Retrievers are known for their friendly and tolerant attitude. They are great with kids and love the outdoors."
  },
  {
    name: "Shiba Inu",
    size: "Medium",
    temperament: "Alert, Independent, Spirited",
    living: "Good for apartments with daily walks",
    image: "https://images.unsplash.com/photo-1619983081563-430f63602791",
    slug: "shiba-inu",
    affiliate: "https://www.amazon.com/s?k=shiba+inu+products",
    details: "Shiba Inus are clean and quiet dogs with a bold personality. They can be stubborn but are very loyal."
  },
  {
    name: "French Bulldog",
    size: "Small",
    temperament: "Adaptable, Playful, Smart",
    living: "Perfect for apartments and small spaces",
    image: "https://images.unsplash.com/photo-1583337130417-3346a1eaa5c3",
    slug: "french-bulldog",
    affiliate: "https://www.amazon.com/s?k=french+bulldog+accessories",
    details: "French Bulldogs are affectionate and easygoing. They don't bark much and enjoy being with their owners."
  }
];

const blogPosts = [
  {
    title: "Top 5 Hypoallergenic Dog Breeds",
    excerpt: "Sneeze-free pups do exist! Discover the best breeds for allergy sufferers.",
    link: "#"
  },
  {
    title: "Best Apartment Dogs in 2025",
    excerpt: "Find out which breeds thrive in smaller spaces without compromising on companionship.",
    link: "#"
  },
  {
    title: "How to Choose the Right Dog for Your Lifestyle",
    excerpt: "Learn how to match your energy level and home setup with the perfect breed.",
    link: "#"
  }
];

export default function Dogopedia() {
  const [query, setQuery] = useState("");

  const filteredBreeds = breeds.filter(breed =>
    breed.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-4xl font-bold mb-6 text-center">
        🐶 Dogopedia – Discover the Best Dog for You
      </h1>

      <p className="text-lg text-center mb-8">
        Explore dog breeds, their characteristics, ideal living conditions,
        and the cutest pictures! Find your perfect companion.
      </p>

      <Input
        placeholder="Search breeds..."
        className="mb-8"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {filteredBreeds.map((breed) => (
          <Card key={breed.name} className="rounded-2xl shadow-md">
            <img
              src={breed.image}
              alt={breed.name}
              className="w-full h-48 object-cover rounded-t-2xl"
            />
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">{breed.name}</h2>
              <p className="text-sm text-gray-600 mb-1">
                <strong>Size:</strong> {breed.size}
              </p>
              <p className="text-sm text-gray-600 mb-1">
                <strong>Temperament:</strong> {breed.temperament}
              </p>
              <p className="text-sm text-gray-600 mb-1">
                <strong>Living:</strong> {breed.living}
              </p>
              <p className="text-sm text-gray-600 mb-2">{breed.details}</p>
              <Button className="w-full">Learn More</Button>
              <a
                href={breed.affiliate}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-blue-600 underline block text-center mt-2"
              >
                Shop for {breed.name} on Amazon
              </a>
            </CardContent>
          </Card>
        ))}
      </div>

      <h2 className="text-2xl font-bold mb-4">📚 Latest Blog Posts</h2>
      <div className="grid gap-6">
        {blogPosts.map((post, index) => (
          <div key={index} className="border rounded-xl p-4 shadow-sm">
            <h3 className="text-xl font-semibold mb-2">{post.title}</h3>
            <p className="text-gray-700 mb-2">{post.excerpt}</p>
            <a
              href={post.link}
              className="text-blue-500 hover:underline"
            >
              Read More
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
